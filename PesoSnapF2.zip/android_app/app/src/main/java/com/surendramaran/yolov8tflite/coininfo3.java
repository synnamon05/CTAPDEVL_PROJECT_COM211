package com.surendramaran.yolov8tflite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class coininfo3 extends AppCompatActivity {

    Button Next2;
    Button Back2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_coininfo3);

        Next2 = findViewById(R.id.next2);
        Back2 = findViewById(R.id.ex3);

        Next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(coininfo3.this, coininfo4.class);
                startActivity(intent);
            }
        });
        Back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(coininfo3.this, Home.class);
                startActivity(intent);
            }
        });
    }
}